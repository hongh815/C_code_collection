


#include <stdio.h>

int  main(void) {

	//소수 
		
	int a;
	printf("2 이상의 정수를 입력하세요 : \n\n");
	scanf("%d", &a);
	printf("\n");
	int count=0;
	int line_count=0;
	int cal;


	for(int i=1; i <= a; i++) {
		for(int j=1; j < i; j++) {
			cal = i % j;
			if(cal == 0) {
				count++;
			}
		}

		if(count == 1) {
			printf("%d\t", i);
			count = 0;
			line_count++;
		}
		else {
			count = 0;
		}

		if(line_count == 5) {
			printf("\n");
			line_count = 0;
		}
	}
}

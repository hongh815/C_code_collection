

#include <stdio.h>

int main(void) {

	int A,B,C;
	int temp, temp2;

	while(1) {

		printf("A 입력 : \n");
		scanf("%d", &A);
		printf("B 입력 : \n");
		scanf("%d", &B);
		printf("C 입력 : \n");
		scanf("%d", &C);

	}
}

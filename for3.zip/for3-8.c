

#include <stdio.h>

int main(void) {

	int count = 0;
	int result = 17;
	int submit;


	while(1) {

		printf("숫자 입력 : (1부터 30까지)\n");
		scanf("%d", &submit);
		
		count++;
		if(submit == result) {
			break;
		} else {
			if(submit > result) printf("%d 보다 작습니다!\n", submit);
			else if(submit < result) printf("%d 보다 큽니다!\n", submit);
		}
	}
	printf("정답입니다..!\n");
	printf("시도한 횟수는 총 %d회 입니다.", count);
}

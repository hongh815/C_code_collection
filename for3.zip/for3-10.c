

#include <stdio.h>

int main(void) {

	int N;
	
	while(1) {
	
	printf("숫자 입력 : \n");
	scanf("%d", &N);

		if(N>=1 && N<=9) {
			for(int j=1; j<10; j++) {
				printf("%d * %d = %d\n", N, j, N*j);
			}
			break;
		} else {
			printf("잘못된 숫자 입력입니다.\n");
		}
	}
}



#include <stdio.h>

int main(void) {

	int i = 0;
	int sum = 0;

	while(1) {

		printf("양수를 입력하세요 : (음수/'0' 입력시 중단)\n");
		scanf("%d", &i);
	
		if(i<=0) {
			break;
		} else {
			sum = sum + i;
		}
	}
	printf("누적된 값 : %d\n", sum);
}

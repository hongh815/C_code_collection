


#include <stdio.h>

int main(void) {


	int sum = 0;

	for(int i=1; i<101; i++) {
	 	printf("%d + %d = %d\n", sum, i, sum+i);
		sum = sum + i;
	}
}

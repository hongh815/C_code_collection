

#include <stdio.h>

int main(void) {

	int a, b;
	int value;
	char c;


	while(1) {

		printf("\n정수 2개와 연산자를 입력하세요.\n");
		scanf("%d %d", &a, &b);
		getchar();
		scanf("%c", &c);
		
		if (c == '+')
		{
			value = a + b;
		}
		else if (c == '-')
		{
			value = a - b;
		}
		else if (c == '*')
		{
			value = a * b;
		}
		else if (c == '/')
		{
			value = a / b;
		}
		else if (c == '%')
		{
			value = a % b;
		}
		else {
			printf("잘못된 입력입니다.\n프로그램을 종료하시겠습니까? (y/n)\n");
			getchar();
			scanf("%c", &c);

			if(c == 'y')
				break;
		} 

		printf("%d %c %d = %d", a, c, b, value);
	}
}

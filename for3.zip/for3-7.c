

#include <stdio.h>

int main(void) {

	for(int i=1; i<10; i++) {
		for(int j=1; j<2; j++) {
			if(i==1 || i==9) {
				printf("*    *");
			}
			else if(i==3 || i==7) {
				printf(" *  * ");
			}
			else if(i==5) {
				printf("  *  ");
			}
			else if(i%2==0) {
				printf("     ");
			}
		}
		printf("\n");
	}
}

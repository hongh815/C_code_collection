

#include <stdio.h>

int main(void) {

	int N;
	int sum=0;
	int num1=0;
	int num2=1;


	printf("N값 입력 : \n");
	scanf("%d", &N);

	for(int i=0; i < N; i++) {
		printf("%d  ", num1);
		sum = num1 + num2;
		num1 = num2;
		num2 = sum;
	}
}

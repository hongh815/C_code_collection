
#include <stdio.h>
#include <stdlib.h>


int main() {
	printf("A : %d\n", 'A');
	printf("a : %d\n", 'a');
	printf("B : %d\n", 'B');
	printf("b : %d\n", 'b');
	printf("C : %d\n", 'C');
	printf("c : %d\n", 'c');
	


	printf("\n%c\n", 65);
	printf("\n%c\n", 65+32);

	char *n;
	int cnt = 0;

	n = (char*)malloc(20*sizeof(char) + 1);

	printf("입력 : \n");
	scanf("%s", n);

	while(1) {
		
		int result_aski = n[cnt++]; 
		
		if(result_aski < 97 && result_aski > 64) {
			result_aski += 32;
		}
		
		printf("%c", result_aski);

		if(cnt == 20) {
			break;
		}
	}
	
	free(n);

}

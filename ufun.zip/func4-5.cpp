

#include <stdio.h>

int disp_menu();

int main() {
	int sel;
	sel = disp_menu();
	if(sel == 0) {
		printf("선택된 메뉴가 없습니다.\n");
	} else {
		printf("선택된 메뉴는 %d 입니다.\n", sel);
	}

	return 0;
}


int disp_menu() {
	int sel;
	printf("1. 볶음짬봉\n2. 콩나물국밥\n3. 바지락칼국수\n\n\n\n#메뉴를 선택하세요. : ");
	scanf("%d", &sel);

	switch(sel) {
		case 1:
			return 1;
			break;
		case 2:	
			return 2;
			break;
		case 3:
			return 3;
			break;
		default :
			return 0;
	}
}

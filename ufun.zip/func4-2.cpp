


#include <stdio.h>

void my_power(int, int);

int main(void) {

	int a,b;
	printf("밑수와 지수를 입력하라. : \n");
	scanf("%d%d", &a, &b);

	my_power(a,b);
}

void my_power(int x, int y) {
	int result = x;

	if(y==1) {
		printf("%d의 %d 제곱의 결과는 = %d.\n", x, y, x);
	} else {
		for(int i=1; i<y; i++) {

			result = result * x;
			printf("%d\n", result);
		}

		printf("%d의 %d 제곱의 결과는 = %d.\n", x, y, result);
	}
}





#include <stdio.h>
#include <stdlib.h>

void ary_sum(int*);

int main(void) {
	int ary[10] = {1, 2};
	int *pary;

	pary = &ary[0];

	ary_sum(pary);

}
void ary_sum(int *x) {

	int sum[10];
	for(int i = 2; i<10; i++) {
		sum[i] = x[i-2] + x[i-1];
		x[i] = sum[i];
	}

	for(int i=0; i<10; i++) {
		printf("%d\t", x[i]);
	}

}




#include <stdio.h>

void arr_print(int*, int*);

int main(void) {
	int A[3] = {1,2,3};
	int B[10];
	int *pA;
	int *pB;

	pA = &A[0];
	pB = &B[0];

	arr_print(pA, pB);

}


void arr_print(int* x, int* y) {
	int cnt = 0;

	for(int i = 0; i < 10; i++) {
			y[i] = x[i];		
			printf("%2d", y[i]);
	}
}

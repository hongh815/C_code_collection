

#include <stdio.h>

int prime_check(int, int*);


int main(void) {

	int a;
	int result = 0;
	printf("소수인지 알고싶은 수를 입력하세요 : \n\n");
	scanf("%d", &a);

	prime_check(a, &result);

	if(result == 1) {

		printf("%d 은 소수입니다.\n", a);

	} else {

		printf("%d 은 소수가 아닙니다.\n", a);

	}

}


int prime_check(int prime, int *result) {

	int count=0;
	int cal;


	for(int j=1; j < prime; j++) {
		cal = prime % j;
		if(cal == 0) {
			count++;
		}
	}

	printf("0으로 딱 나누어지는 만큼 카운트 : %d\n", count);
	if(count == 1) {
		*result = 1;
		count = 0;
	}
	else {
		count = 0;
		*result = 0;
	}

	return *result;
}

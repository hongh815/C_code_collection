
#include <stdio.h>



void count_lotto();

int main(void) {
	count_lotto();

}


void count_lotto() {

	int n;
	int narr[6];
	int sum = 0;
	int cnt = 0;
	while(cnt < 6) {
		printf("로또번호 입력 : \n");
		scanf("%d", &n);
		narr[cnt++] = n;
		
		if(narr[cnt] == narr[cnt - 1] && cnt > 1) {
			printf("중복");
			cnt--;
		}

	}
	printf("sdf");
}

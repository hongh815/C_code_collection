

#include <stdio.h>

void cal_avg();

int main(void) {

	cal_avg();
}


void cal_avg() {
//5명 심사위원의 점수 입력 :79485 유효점수 :785
//평균 : 6.7

	int a,b,c;
	int d,e;

	printf("5명의 심사위원의 점수 입력 : ");
	scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);

	int arr[5] = {a, b, c, d, e};

	printf("\n\n");

	int result[5] = {0};
	int result_avg[5] = {0};
	int count = 0;
	int temp[5];

	for(int i=0; i<5; i++) {
		temp[i] = arr[i];
		result[i] = arr[i];
	}

	printf("\n\n");

	while(count < 6) {
		for(int i=0; i<5; i++) {
			result[i] -= 1;
			if(result[i] < 0) {
				count++;
				if(count == 1) {
					result_avg[0] = temp[i];
				}
			}
				
		}
	printf("\n\n");
	for(int i=0; i<5; i++) {
		printf("%d\n", result_avg[i]);
	}
}

}

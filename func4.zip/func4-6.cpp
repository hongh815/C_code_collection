

#include <stdio.h>


int total(int,int,int);
double average(int);
void print_title(void);



int main(void) {

	int kor, eng, mat;
	int tot;
	double avg;

	printf("# 세 과목의 점수 입력 : ");
	scanf("%d%d%d", &kor, &eng, &mat);

	tot = total(kor, eng, mat);
	avg = average(tot);
	
	print_title();
	printf("\t%d  %d  %d  %d  %.1lf\n", kor, eng, mat, tot, avg);
}


int total(int kor, int eng, int mat) {

	int tot = 0;
	tot = kor + eng + mat;

	return tot;
}

double average(int tot) {

	double avg = (double)tot / 3;

	return avg;
}

void print_title(void) {

printf("\n\t==== < 성적표 > ====\n\n");
printf("----------------------------------------------------\n\n");
printf("\t국어 영어 수학 총점 평균\n\n");
printf("----------------------------------------------------\n\n");

}






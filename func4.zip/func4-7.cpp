


#include <stdio.h>

double arr_back(double);

int main() {

	double ary[5] = { 1.0, 2.1, 3.2, 4.3, 5.4 };

}

double arr_back(double a) {



}


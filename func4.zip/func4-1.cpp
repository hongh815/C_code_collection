


#include <stdio.h>

void centi_to_meter(int);


int main(void) {

	int cm;
	printf("cm를 입력하세요 : \n");
	scanf("%d", &cm);

	centi_to_meter(cm);
}


void centi_to_meter(int x) {

	float meter;

	meter = (float)x / 100;
	printf("\n%.2f m\n", meter);
}


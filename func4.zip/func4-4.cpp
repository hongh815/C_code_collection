


#include <stdio.h>

void sum(int);

int main() {

	sum(10);

	sum(100);

	return 0;
}


void sum(int x) {


	int sum = 0;

	for(int i=1; i<=x; i++) {
		sum = sum + i;
	}
	printf("1부터 %d 까지의 합은 %d 입니다.\n\n", x, sum);
}

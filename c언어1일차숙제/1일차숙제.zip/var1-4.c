#include <stdio.h>

int main(void) {

	int g = 70;
	int e = 80;
	int	m = 90;

	int sum = g + e + m;

	printf("국어 : %d, 영어 : %d, 수학 : %d\n", g, e, m);
	printf("총점 : %d", sum);
}

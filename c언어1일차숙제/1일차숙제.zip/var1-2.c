#include <stdio.h>

int main(void)
{
	printf("학번: %d\n", 32165);
	printf("이름: %s\n", "김홍범");
	printf("학점: %s\n", "A");

}

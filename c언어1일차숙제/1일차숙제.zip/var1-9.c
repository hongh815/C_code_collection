

#include <stdio.h>

int main(void) {

	printf("4 + 1.2 = %.1f\n", 4.0+1.2);
	printf("4 - 1.2 = %.1f\n", 4.0-1.2);
	printf("4 * 1.2 = %.1f\n", 4.0*1.2);
	printf("4 / 1.2 = %.1f\n", 4.0/1.2);
}
